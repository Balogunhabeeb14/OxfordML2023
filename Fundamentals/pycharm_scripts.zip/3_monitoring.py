""" 5. Monitoring Training """

import os
os.system('tensorboard --logdir results --host 127.0.0.1')
